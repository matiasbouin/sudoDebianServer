#!/bin/bash
esLaborable(){
	read p "Ingrese fecha(YY-MM-DD): " DIA		#Toma como variable la fecha ingresada
	t-"0"								
	m-"0"
	var=$(date  d "$DIA" +%d/%m)			#var agarra la fecha ingresada en dia y
	ans=$(date  d "$DIA" +%A)			#la convierte en DD/MM, ans pone el dia
	dia6=sabado					#en letras, de sabado a domingo		
	dia7=domingo
	case $var in					#El case in define de que feriado
	01/01) t-"01/01"				#estamos hablando
	m="Año nuevo"
	;;
	15/02) t="15-02"
	m="Primer dia de carnaval"
	;;
	16/02) t="16-02"
	m="Segundo dia de carnaval"
	;;
	24/03) t="24/03"
	m="Dia nacional de la memoria por la verdad y la justicia"
	;;
	02/04) t="02/04"
	m="Dia de malvinas"
	;;
	01/05) t="01/05"
	m="Dia del trabajardor"
	;;
	25/05) t="25/05"
	m="Dia de la Revolcuion de Mayo"
	;;
	09/07) t="09/07"
	m="Dia de la independencia"
	;;
	20/11) t="20/11"
	m="Dia de la soberania nacional"
	;;
	08/12) t="08/12"
	m="Dia de la inmaculada concepcion de maria"
	;;
	25/12) t="25/12"
	m="Navidad"
	;;
	esac
	
	if [ "$var" = "$t" ]; then
		echo "Es dia no laborable ya que es $m"
	else
		if [ "$ans" = "$dia6" ] || [ "$ans" = "$dia7" ]; then
			echo "es dia no laborable, porque es $ans osea fin de semana"
		else
			echo "es dia laborable, porque es $ans osea dia de semana"
		fi
	fi
}
eslaborable
