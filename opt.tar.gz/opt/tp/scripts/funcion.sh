#!/bin/bash

read -p "Ingrese fecha(YY-MM-DD): " DIA

esLaborable(){
	ans=$(date -d "$DIA" +%A)
	dia6=sábado
	dia7=domingo
	if [ "$ans" = "$dia6" ] || [ "$ans" = "$dia7" ]; then
		echo "Es dia no laborable porque $ans es fin de semana, entonces se descansa"
	else
		echo "Es dia laborable por que $ans es dia de semana, entonces se trabaja"
	fi

}
esLaborable
