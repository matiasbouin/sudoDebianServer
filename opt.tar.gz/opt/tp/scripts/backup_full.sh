#!/bin/bash

function help() {
	echo "Ingrese: bash backup_full.sh <punto de origen> <punto de destino>"
}

[ "$1" == "-h" ] && help && exit 0

if [ ! $# -eq 2 ]; then
	echo "Solo 2 argumentos"
	help
	exit 1
fi

if [ ! -d "$1" ] && [ ! -d "$2" ]; then
	echo "Se deben ingresar directorios"
	exit 1
fi

BACKUPEAR=$1
DESTINO=$2
BACKUPDATE=`date +%Y%m%d`
BACKUPTIME=`date +%H:%M:%S`

echo
echo "Se hara el backup de `basename $BACKUPEAR`"
echo "Se pondra en `basename $DESTINO`"
echo "En el dia $BACKUPDATE"
echo

mountpoint $BACKUPEAR 2>/dev/null >&2

if [ ! $? -eq 0 ]; then
	echo "No es un punto de montaje ($BACKUPEAR)"
else
	echo "Es un punto de montaje"
fi
echo

mountpoint $DESTINO 2>/dev/null >&2

if [ ! $? -eq 0 ]; then
	echo "No es un punto de montaje ($DESTINO)"
else
	echo "Es un punto de montaje"
fi
echo

tar -cpzf `basename $BACKUPEAR`-bkp-$BACKUPDATE.tar.gz $BACKUPEAR && echo "$BACKUPTIME - Se hizo el backup de `basename $BACKUPEAR`" >>logs.txt

if [ ! $? -eq 0 ]; then
	echo "Se envian los logs porque se genero un backup" | mutt -s "Logs de backup" -a /opt/tp/scripts/logs.txt root@debian
	echo "Backup finalizado correctamente"
else
	echo "Algo ha fallado"
fi
 
