#!/bin/bash

PROC=$1

if [ -z "`ps -ef|grep $1|grep -v grep`" ]
then
	echo "el proceso no esta en funcionamiento" | mail -s "monitor" root@debian

fi

exit 0
