#!/bin/bash


$1


if [ $1 ]
then
	ps -ef | grep $1

else
	echo "El proceso no esta en funcionamiento" | mail -s "monitor" root@debian


fi
