#!/bin/bash

PROCESO=usr/sbin/sshd

if [ $PROCESO ]
then
	ps -ef | grep $PROCESO

else
	echo "El proceso no esta en funcionamiento" | mail -s "monitor" root@debian
fi

PROCESO1=/usr/sbin/mysqld

if [ $PROCESO1 ]
then
	ps -ef | grep $PROCESO1
else
	echo "El proceso no esta en funcionamiento" | mail -s "monitor" root@debian
fi

PROCESO2=/usr/sbin/apache2

if [ $PROCESO2 ]
then
	ps -ef | grep $PROCESO2
else
	echo "El proceso no esta funcionamiento" | mail -l "monitor" root@debian
fi


